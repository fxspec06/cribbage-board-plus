/*
 * Copyright 2012 fxspec06 (Bryan Leasot)
 * Not for distribution
 * 
 */
enyo.depends(
	"objects.js",
	"sha256.js"
);