/*
 * Copyright 2012 fxspec06 (Bryan Leasot)
 * Not for distribution
 * 
 */
enyo.depends(
	"alert.js",
	"colorpicker.js",
	"panelsExt.js"
);