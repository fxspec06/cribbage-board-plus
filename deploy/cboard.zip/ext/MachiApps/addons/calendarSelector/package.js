enyo.depends(
	"calendarSelector.js",
	"calendarSelector.css"
);