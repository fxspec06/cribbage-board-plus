enyo.depends(
	"ColorPicker.js",
	"ColorPicker.css"
);