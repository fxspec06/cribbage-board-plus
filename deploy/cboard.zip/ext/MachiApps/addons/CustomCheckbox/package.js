enyo.depends(
	"CustomCheckbox.js",
	"CustomCheckbox.css"
);