/*
 * Copyright 2012 fxspec06 (Bryan Leasot)
 * Not for distribution
 * 
 */
enyo.depends(
	
	
	"$lib/onyx",
	//"$lib/extra/jsonp",
	
	"ext/MachiApps/addons/ColorPicker/",
	
	
	"srcs/package.js",
	"srcs/lib",
	"srcs/com"
	//"srcs/extra",
	
	
	
);